document.addEventListener("DOMContentLoaded", function() {
    const likeButtons = document.querySelectorAll(".like-button");
    const deleteButtons = document.querySelectorAll(".delete-button");
    const minusButtons = document.querySelectorAll(".minus-button");
    const plusButtons = document.querySelectorAll(".plus-button");
    const quantityElements = document.querySelectorAll(".quantity");
    const totalAmountElement = document.querySelector(".total-amount");
    
    let totalAmount = 100; // Initial total amount
    
    likeButtons.forEach(button => {
        button.addEventListener("click", function() {
            button.classList.toggle("liked");
        });
    });
    
    deleteButtons.forEach(button => {
        button.addEventListener("click", function() {
            const BMW = button.closest(".cart-BMW");
            BMW.remove();
            updateTotal();
        });
    });
    
    minusButtons.forEach(button => {
        button.addEventListener("click", function() {
            const quantityElement = button.nextElementSibling;
            let quantity = parseInt(quantityElement.textContent);
            if (quantity > 1) {
                quantity--;
                quantityElement.textContent = quantity;
                updateTotal();
            }
        });
    });
    
    plusButtons.forEach(button => {
        button.addEventListener("click", function() {
            const quantityElement = button.previousElementSibling;
            let quantity = parseInt(quantityElement.textContent);
            quantity++;
            quantityElement.textContent = quantity;
            updateTotal();
        });
    });
    
    function updateTotal() {
        totalAmount = 0;
        quantityElements.forEach(element => {
            const BMW = element.closest(".cart-BMW");
            const price = parseFloat(BMW.querySelector("p").textContent.slice(1));
            const quantity = parseInt(element.textContent);
            totalAmount += price * quantity;
        });
        totalAmountElement.textContent = "$" + totalAmount.toFixed(2);
    }
});
